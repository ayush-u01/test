export { AuthRoute } from "./AuthModule/auth.route";
export { PasswordRoute } from "./PasswordModule/password.route";
export { ChatRoute } from "./ChatModule/chat.route";
export { PdfRoute } from "./PDFModule/pdf.route";
