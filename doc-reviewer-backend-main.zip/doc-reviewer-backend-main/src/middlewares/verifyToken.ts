import { verifyAccessToken } from "utils/token";
export const verifyToken = verifyAccessToken;
